[app]
title = Lector Kral
package.name = lectorkral
package.domain = org.kral
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,mp3,wav
version = 0.1
requirements = python3,kivy
orientation = portrait
fullscreen = 0
android.archs = armeabi-v7a, arm64-v8a
android.allow_backup = True
